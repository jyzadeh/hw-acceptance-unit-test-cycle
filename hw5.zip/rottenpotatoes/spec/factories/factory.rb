FactoryGirl.define do
    factory :movie do
        title 'Movie'
        rating 'R'
        description 'None'
        release_date '01-01-1990'
    end
end